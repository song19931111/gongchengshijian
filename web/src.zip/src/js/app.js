/**
 * Created by xiangsong on 2017/4/2.
 */
var mainApp = angular.module('mainApp',['ui.router']);
mainApp.config(function ($stateProvider,$urlRouterProvider) {
    $urlRouterProvider.otherwise('/index');
    $stateProvider
        .state('index', {
            url: '/index',
            views: {
                '': {
                    templateUrl: 'tpls/main.html'
                },
                'nav@index': {
                    templateUrl: 'tpls/nav.html'
                },
                'content@index': {
                    templateUrl: 'tpls/home/home.html'
                },
                'bottom@index':{
                    templateUrl:'tpls/bottom.html'
                }
            }
        })
});