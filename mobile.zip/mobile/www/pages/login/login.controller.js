(function () {
        'use strict';
        angular.module('starter.controllers')
            .controller('LoginCtrl',['$scope',function ($scope) {

            }])

})()
